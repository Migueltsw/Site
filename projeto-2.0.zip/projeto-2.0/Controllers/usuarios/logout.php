<?php

logout();
header('Location: /');