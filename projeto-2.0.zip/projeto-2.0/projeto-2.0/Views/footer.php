<div class="footer">
    <div style='min-height:0px' class='content'>
        <div class='footer-items'>
            <p>IFRN Campus Caicó</p>
            <p>By: Informática para Internet 2021.1</p>
            <p>Contate-nos: 00 9999 - 8888 | 00 9999 - 8888</p>
        </div>
    </div>
</div>
    <script src="../static/js/script.js"></script>
</body>

</html>